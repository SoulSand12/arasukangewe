<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

$userId = $_SESSION['user_id'];

$users = json_decode(file_get_contents('users.json'), true);
$user = $users[$userId];

// Acak urutan postingan
$posts = json_decode(file_get_contents('postingan.json'), true);
shuffle($posts);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profil</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }

        .profile-container {
            max-width: 800px;
            margin: auto;
            padding: 20px;
        }

        .profile-header {
            background-color: #3498db;
            color: #fff;
            padding: 10px;
            text-align: center;
            font-size: 18px;
        }

        .profile-section {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 20px;
        }

        .profile-info,
        .post-content {
            margin-top: 10px;
        }

        .profile-info,
        .post {
            background-color: #fff;
            border: 1px solid #ddd;
            padding: 15px;
            border-radius: 8px;
        }

        .profile-picture {
            width: 80px;
            height: 80px;
            margin-right: 20px;
            border-radius: 50%;
        }

        button {
            background-color: #3498db;
            color: #fff;
            padding: 10px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        button:hover {
            background-color: #2980b9;
        }

        img, video {
            max-width: 100%;
            height: auto;
            margin-top: 10px;
        }
    </style>
</head>
<body>
    <div class='profile-container'>
        <div class='profile-header'>
            <a href="beranda.php">Beranda</a> |
            <a href="index.php">Chat</a> |
            <a href="post.php" class="post-button">Post</a>
        </div>

        <div class='profile-section'>
            <div class='profile-info'>
                <img src='<?php echo $user['profile_picture']; ?>' alt='Profile Picture' class='profile-picture'>
                <strong><?php echo $user['username']; ?>:</strong>
            </div>
            <button onclick="location.href='edit_profile.php';">Edit Profil</button>
        </div>

        <?php
        // Menampilkan postingan
        foreach ($posts as $post) {
            if ($post['sender_id'] == $userId) {
                $postId = $post['post_id'];
                $senderId = $post['sender_id'];
                $senderName = $users[$senderId]['username'];
                $senderProfilePicture = $users[$senderId]['profile_picture'];
                $postContent = $post['message'];
                $postImage = $post['image'];
                $postVideo = $post['video'];
                $likes = isset($post['like']) ? $post['like'] : [];
                $likeCount = count($likes);

                echo "<div class='post'>";
                echo "<div class='profile-info'>";
                echo "<img src='$senderProfilePicture' alt='Profile Picture' class='profile-picture'>";
                echo "<strong>$senderName:</strong>";
                echo "</div>";

                if ($postImage !== null && file_exists($postImage)) {
                    echo "<img src='$postImage' alt='Posted Image'>";
                }

                if ($postVideo !== null && file_exists($postVideo)) {
                    echo "<video controls>";
                    echo "<source src='$postVideo' type='video/mp4'>";
                    echo "Your browser does not support the video tag.";
                    echo "</video>";
                }

                echo "<div class='post-content'>";
                echo "<p>$postContent</p>";
                echo "<div class='post-actions'>";
                echo "<button class='like-button' data-post-id='$postId'>Like (<span class='like-count'>$likeCount</span>)</button>";
                echo "<a href='komentar.php?post_id=$postId'>Komentar</a>";
                echo "</div>";
                echo "</div>";

                echo "</div>";
            }
        }
        ?>
    </div>

    <script>
        document.querySelectorAll('.like-button').forEach(button => {
            button.addEventListener('click', async () => {
                const postId = button.getAttribute('data-post-id');
                const response = await fetch('beranda.php', {
                    method: 'POST',
                    body: new URLSearchParams({ post_id: postId }),
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded'
                    }
                });

                if (response.ok) {
                    const likeCountElement = button.querySelector('.like-count');
                    const currentCount = parseInt(likeCountElement.innerText);
                    const newCount = response.status === 201 ? currentCount + 1 : currentCount - 1;
                    likeCountElement.innerText = newCount;
                }
            });
        });
    </script>
</body>
</html>
