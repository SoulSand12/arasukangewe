<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

$userId = $_SESSION['user_id'];

$users = json_decode(file_get_contents('users.json'), true);
$user = $users[$userId];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Handle form submission (Update profile)
    $newUsername = $_POST['new_username'];

    // Validate and update user data
    if (!empty($newUsername)) {
        $user['username'] = $newUsername;
    }

    // Handle file upload for profile picture
    if (!empty($_FILES['new_profile_media']['name'])) {
        $uploadDir = 'uploads/';
        $uploadFile = $uploadDir . basename($_FILES['new_profile_media']['name']);
        move_uploaded_file($_FILES['new_profile_media']['tmp_name'], $uploadFile);

        // Update profile_picture in users.json with the uploaded file name
        $user['profile_picture'] = $uploadFile;
    }

    $users[$userId] = $user;
    file_put_contents('users.json', json_encode($users, JSON_PRETTY_PRINT));

    // Redirect back to profile page
    header('Location: profile.php');
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Profil</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }

        .edit-profile-container {
            max-width: 600px;
            margin: auto;
            padding: 20px;
            background-color: #fff;
            border: 1px solid #ddd;
            border-radius: 8px;
            margin-top: 20px;
        }

        .edit-profile-header {
            background-color: #3498db;
            color: #fff;
            padding: 10px;
            text-align: center;
            font-size: 18px;
        }

        .edit-profile-form {
            margin-top: 20px;
        }

        label {
            display: block;
            margin-bottom: 8px;
        }

        input {
            width: 100%;
            padding: 8px;
            margin-bottom: 15px;
            box-sizing: border-box;
        }

        button {
            background-color: #3498db;
            color: #fff;
            padding: 10px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        button:hover {
            background-color: #2980b9;
        }
    </style>
</head>
<body>
    <div class='edit-profile-container'>
        <div class='edit-profile-header'>
            <a href="profile.php">Kembali ke Profil</a>
        </div>

        <div class='edit-profile-form'>
            <form method="POST" action="" enctype="multipart/form-data">
                <label for="new_username">Edit Nama:</label>
                <input type="text" id="new_username" name="new_username" value="<?php echo $user['username']; ?>">

                <label for="new_profile_media">Edit Media Profil (Image/Video):</label>
                <input type="file" id="new_profile_media" name="new_profile_media" accept="image/*,video/*">

                <button type="submit">Simpan Perubahan</button>
            </form>
        </div>
    </div>
</body>
</html>
