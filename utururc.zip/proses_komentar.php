<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

$userId = $_SESSION['user_id'];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['post_id'], $_POST['komentar'])) {
    $postId = $_POST['post_id'];
    $commentContent = $_POST['komentar'];
    $gambar = null;

    // Cek apakah ada file gambar yang diupload
    if (isset($_FILES['gambar']) && $_FILES['gambar']['error'] === UPLOAD_ERR_OK) {
        $gambarDir = 'komentargambar/';
        $gambarPath = $gambarDir . basename($_FILES['gambar']['name']);

        // Pastikan direktori sudah ada atau buat baru
        if (!file_exists($gambarDir)) {
            mkdir($gambarDir, 0777, true);
        }

        // Pindahkan file gambar ke direktori yang ditentukan
        move_uploaded_file($_FILES['gambar']['tmp_name'], $gambarPath);
        $gambar = $gambarPath;
    }

    // Buat data komentar
    $comment = [
        'user_id' => $userId,
        'komentar' => $commentContent,
        'gambar' => $gambar,
    ];

    // Simpan komentar ke postingan.json
    $posts = json_decode(file_get_contents('postingan.json'), true);

    if (isset($posts[$postId]['komentar'])) {
        $posts[$postId]['komentar'][] = $comment;
    } else {
        $posts[$postId]['komentar'] = [$comment];
    }

    file_put_contents('postingan.json', json_encode($posts, JSON_PRETTY_PRINT));
}

// Redirect kembali ke komentar.php
header("Location: komentar.php?post_id=$postId");
exit();
?>
