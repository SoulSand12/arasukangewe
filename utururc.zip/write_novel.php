<?php
session_start();

// Redirect user to login page if not logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

// Load novel data from JSON file
$novelData = [];
if (file_exists('novel_data.json')) {
    $novelData = json_decode(file_get_contents('novel_data.json'), true);
}

// Check if novel ID is provided in the URL
if (isset($_GET['id'])) {
    $novelId = $_GET['id'];

    // Check if the provided novel ID exists in the data
    if (isset($novelData[$novelId])) {
        // Get the novel details
        $novel = $novelData[$novelId];
    } else {
        // Redirect to novel list if novel ID is invalid
        header('Location: novel_list.php');
        exit();
    }
} else {
    // Redirect to novel list if novel ID is not provided
    header('Location: novel_list.php');
    exit();
}

// Check if form is submitted to add a new chapter
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Validate form data
    if (isset($_POST['chapter_content'])) {
        $newChapterContent = $_POST['chapter_content'];
        // Add new chapter to the novel data
        $novelData[$novelId]['chapters'][] = $newChapterContent;
        // Save the updated novel data to the JSON file
        file_put_contents('novel_data.json', json_encode($novelData, JSON_PRETTY_PRINT));
        // Refresh the page to show the newly added chapter
        header("Location: write_novel.php?id=$novelId");
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Write Novel - <?php echo $novel['judul']; ?></title>
<style>
    body {
        font-family: Arial, sans-serif;
        background-color: #f4f4f4;
        margin: 0;
        padding: 0;
    }

    .container {
        max-width: 100%; /* Mengubah lebar maksimum menjadi 100% */
        margin: 20px auto;
        padding: 20px;
        background-color: #fff;
        border-radius: 10px;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    }

    h2 {
        margin-top: 0;
        padding-top: 0;
    }

    .chapter-form {
        margin-bottom: 20px;
    }

    label {
        display: block;
        font-weight: bold;
        margin-bottom: 5px;
    }

    textarea {
        width: calc(100% - 10px);
        height: 80vh; /* Mengatur tinggi textarea menjadi 80% dari tinggi viewport */
        padding: 8px;
        margin-bottom: 10px;
        border: 1px solid #ccc;
        border-radius: 5px;
        box-sizing: border-box;
        resize: vertical;
    }

    button {
        padding: 10px 20px;
        background-color: #007bff;
        color: #fff;
        border: none;
        border-radius: 5px;
        cursor: pointer;
        transition: background-color 0.3s ease;
    }

    button:hover {
        background-color: #0056b3;
    }

    .chapter-list {
        list-style-type: none;
        padding: 0;
        margin: 0;
    }

    .chapter {
        margin-bottom: 20px;
        border: 1px solid #ddd;
        padding: 10px;
        border-radius: 5px;
    }

    .chapter-content {
        margin-top: 10px;
    }
</style>
</head>
<body>
    <div class="container">
        <h2>Write Novel - <?php echo $novel['judul']; ?></h2>
        <!-- Form to add a new chapter -->
        <div class="chapter-form">
            <form method="post">
                <label for="chapter_content">New Chapter:</label><br>
                <textarea id="chapter_content" name="chapter_content" required></textarea><br>
                <button type="submit">Add Chapter</button>
            </form>
        </div>
        <!-- List of chapters -->
        <div class="chapter-list">
            <?php foreach ($novel['chapters'] as $index => $chapter): ?>
                <div class="chapter">
                    <div class="chapter-content">
                        <strong>Chapter <?php echo $index + 1; ?>:</strong><br>
                        <?php echo $chapter; ?>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
        <!-- Button to save novel data -->
        <form method="post">
            <input type="hidden" name="save_novel" value="1">
            <button type="submit">Save Novel</button>
        </form>
    </div>
</body>
</html>