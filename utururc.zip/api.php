<?php
// Mendapatkan data dari file JSON
function getData() {
    $file = 'database.json';
    if (file_exists($file)) {
        return file_get_contents($file);
    } else {
        return json_encode(array('error' => 'File not found'));
    }
}

// Menulis data ke file JSON
function writeData($data) {
    $file = 'database.json';
    file_put_contents($file, $data);
    return json_encode(array('message' => 'Data written successfully'));
}

// Memproses permintaan
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    echo getData();
} elseif ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $requestData = file_get_contents('php://input');
    echo writeData($requestData);
}
?>