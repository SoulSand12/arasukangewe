<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

$userId = $_SESSION['user_id'];

$users = json_decode(file_get_contents('users.json'), true);
$posts = json_decode(file_get_contents('postingan.json'), true);

if (!isset($_GET['post_id'])) {
    header('Location: beranda.php');
    exit();
}

$postId = $_GET['post_id'];
$postToEdit = null;

foreach ($posts as &$post) {
    if ($post['post_id'] == $postId && $post['sender_id'] == $userId) {
        $postToEdit = &$post;
        break;
    }
}

if ($postToEdit === null) {
    header('Location: beranda.php');
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['delete'])) {
        // Delete associated images and videos
        foreach ($postToEdit['images'] as $image) {
            if (file_exists($image)) {
                unlink($image);
            }
        }
        foreach ($postToEdit['videos'] as $video) {
            if (file_exists($video)) {
                unlink($video);
            }
        }

        // Delete post
        $posts = array_filter($posts, function ($post) use ($postId) {
            return $post['post_id'] !== $postId;
        });
        file_put_contents('postingan.json', json_encode($posts, JSON_PRETTY_PRINT));
        header('Location: beranda.php');
        exit();
    } else {
        $message = htmlspecialchars($_POST['message']);
        $timestamp = time();
        $postImages = $postToEdit['images'] ?? [];
        $postVideos = $postToEdit['videos'] ?? [];

        // Process multiple images
        if (!empty(array_filter($_FILES['post_images']['name']))) {
            $targetDir = 'post/';
            foreach ($_FILES['post_images']['tmp_name'] as $key => $tmp_name) {
                $postImage = $targetDir . uniqid() . '_' . basename($_FILES['post_images']['name'][$key]);
                move_uploaded_file($tmp_name, $postImage);
                $postImages[] = $postImage;
            }
        }

        // Process multiple videos
        if (!empty(array_filter($_FILES['post_videos']['name']))) {
            $targetDir = 'post/';
            foreach ($_FILES['post_videos']['tmp_name'] as $key => $tmp_name) {
                $postVideo = $targetDir . uniqid() . '_' . basename($_FILES['post_videos']['name'][$key]);
                move_uploaded_file($tmp_name, $postVideo);
                $postVideos[] = $postVideo;
            }
        }

        // Get selected categories
        $categories = $_POST['categories'] ?? [];

        $postToEdit['message'] = $message;
        $postToEdit['images'] = $postImages;
        $postToEdit['videos'] = $postVideos;
        $postToEdit['timestamp'] = $timestamp;
        $postToEdit['categories'] = $categories;

        file_put_contents('postingan.json', json_encode($posts, JSON_PRETTY_PRINT));

        // Redirect to avoid form resubmission on refresh
        header('Location: beranda.php');
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Postingan</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }

        .edit-container {
            max-width: 600px;
            margin: auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            margin-top: 50px;
        }

        .edit-form {
            display: flex;
            flex-direction: column;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            font-weight: bold;
            margin-bottom: 10px;
        }

        .form-group input[type="file"] {
            width: 100%;
            padding: 10px;
            box-sizing: border-box;
            margin-top: 5px; /* Adjust spacing */
        }

        .form-group textarea {
            width: 100%;
            height: 100px;
            padding: 10px;
            box-sizing: border-box;
            margin-top: 5px; /* Adjust spacing */
        }

        .form-group button {
            background-color: #3498db;
            color: #fff;
            padding: 10px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        .form-group button:hover {
            background-color: #2980b9;
        }

        .delete-button {
            background-color: #e74c3c;
            margin-top: 10px;
        }

        .delete-button:hover {
            background-color: #c0392b;
        }

        /* Category Text Colors */
        .category-meme { color: #FF5733; }
        .category-quotes { color: #9B59B6; }
        .category-darkmeme { color: #34495E; }
        .category-foryoupage { color: #27AE60; }
        .category-random { color: #E67E22; }
    </style>
</head>
<body>
    <div class='edit-container'>
        <h2>Edit Postingan</h2>
        <form method='post' action='edit_post.php?post_id=<?php echo $postId; ?>' enctype='multipart/form-data' class='edit-form'>
            <div class='form-group'>
                <label for='message'>Kata-kata:</label>
                <textarea name='message' id='message' placeholder='Tulis pesanmu...'><?php echo $postToEdit['message']; ?></textarea>
            </div>
            <div class='form-group'>
                <label for='post_images'>Unggah Gambar Baru (multiple):</label>
                <input type='file' name='post_images[]' id='post_images' accept='image/*' multiple>
            </div>
            <div class='form-group'>
                <label for='post_videos'>Unggah Video Baru (multiple):</label>
                <input type='file' name='post_videos[]' id='post_videos' accept='video/*' multiple>
            </div>
            <div class='form-group'>
                <label>Pilih Kategori:</label>
                <?php
                $categories = ['meme', 'quotes', 'darkmeme', 'foryoupage', 'random'];
                foreach ($categories as $category) {
                    $checked = in_array($category, $postToEdit['categories']) ? 'checked' : '';
                    echo "<input type='checkbox' name='categories[]' value='$category' $checked>";
                    echo "<label for='$category' class='category-$category'>" . ucfirst($category) . "</label><br>";
                }
                ?>
            </div>
            <div class='form-group'>
                <button type='submit'>Simpan Perubahan</button>
            </div>
        </form>
        <form method='post' action='edit_post.php?post_id=<?php echo $postId; ?>' class='edit-form'>
            <div class='form-group'>
                <button type='submit' name='delete' class='delete-button'>Hapus Postingan</button>
            </div>
        </form>
    </div>
</body>
</html>
