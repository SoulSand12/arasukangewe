<?php
session_start();

// Function to load JSON data from file
function loadJSON($filename) {
    $data = file_get_contents($filename);
    return json_decode($data, true);
}

// Function to save JSON data to file
function saveJSON($filename, $data) {
    file_put_contents($filename, json_encode($data, JSON_PRETTY_PRINT));
}

// Redirect user to login page if not logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

// Get user ID from session
$userId = $_SESSION['user_id'];

// Load users and groups data from JSON files
$users = loadJSON('users.json');
$groups = loadJSON('groups.json');

// Get group ID from URL parameter
$groupId = $_GET['group_id'] ?? null;

// Redirect user if group ID is not provided or group does not exist
if (!$groupId || !isset($groups[$groupId]) || $groups[$groupId]['admin_id'] !== $userId) {
    header('Location: index.php');
    exit();
}

// Get group data
$group = $groups[$groupId];

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['update_name'])) {
        $newGroupName = htmlspecialchars($_POST['group_name']);
        $groups[$groupId]['group_name'] = $newGroupName;
    } elseif (isset($_POST['update_profile'])) {
        // Handle group profile picture update if needed
        if ($_FILES['profile_picture']['error'] === UPLOAD_ERR_OK) {
            $uploadDir = 'db_group/'; // Directory to store group profile pictures
            $uploadPath = $uploadDir . $_FILES['profile_picture']['name'];
            move_uploaded_file($_FILES['profile_picture']['tmp_name'], $uploadPath);
            $groups[$groupId]['group_picture'] = $uploadPath;
        }
    } elseif (isset($_POST['add_member'])) {
        $selectedMembers = $_POST['members'] ?? [];
        foreach ($selectedMembers as $memberId) {
            if (!in_array($memberId, $group['members']) && $memberId !== $userId && isset($users[$memberId])) {
                $groups[$groupId]['members'][] = $memberId;
            }
        }
    } elseif (isset($_POST['remove_member'])) {
        $selectedMembers = $_POST['members'] ?? [];
        foreach ($selectedMembers as $memberId) {
            $key = array_search($memberId, $group['members']);
            if ($key !== false) {
                unset($groups[$groupId]['members'][$key]);
            }
        }
    }

    // Save changes to JSON file
    saveJSON('groups.json', $groups);

    // Redirect to prevent form resubmission
    header("Location: setting_group.php?group_id=$groupId");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Group Settings</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }

        .container {
            max-width: 800px;
            margin: 20px auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        h2 {
            margin-top: 0;
            padding-top: 0;
        }

        form {
            margin-bottom: 20px;
        }

        label {
            display: block;
            font-weight: bold;
            margin-bottom: 5px;
        }

        input[type="text"],
        input[type="file"],
        select {
            width: calc(100% - 10px);
            padding: 8px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-sizing: border-box;
        }

        button {
            padding: 10px 20px;
            background-color: #007bff;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        button:hover {
            background-color: #0056b3;
        }

        select {
            width: 100%;
        }

        .checkbox-list {
            list-style-type: none;
            padding: 0;
            margin: 0;
        }

        .checkbox-item {
            margin-bottom: 5px;
        }

        .profile-picture {
            width: 30px;
            height: 30px;
            border-radius: 50%;
            margin-right: 10px;
        }

        a {
            display: block;
            margin-top: 20px;
            text-decoration: none;
            color: #007bff;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Group Settings - <?php echo $group['group_name']; ?></h2>

        <!-- Update Group Name Form -->
        <form method="post">
            <label>New Group Name:</label>
            <input type="text" name="group_name" value="<?php echo $group['group_name']; ?>" required>
            <button type="submit" name="update_name">Update Name</button>
        </form>

        <!-- Update Group Profile Form -->
        <form method="post" enctype="multipart/form-data">
            <label>New Group Profile Picture:</label>
            <input type="file" name="profile_picture" accept="image/*" required>
            <button type="submit" name="update_profile">Update Profile</button>
        </form>
        
        <!-- Add Member Form -->
        <h3>Add Member</h3>
        <form method="post">
            <ul class="checkbox-list">
                <?php foreach ($users as $user): ?>
                    <?php if (!in_array($user['user_id'], $group['members']) && $user['user_id'] !== $userId): ?>
                        <li class="checkbox-item">
                            <input type="checkbox" id="add_<?php echo $user['user_id']; ?>" name="members[]" value="<?php echo $user['user_id']; ?>">
                            <label for="add_<?php echo $user['user_id']; ?>">
                                <?php if (isset($user['profile_picture'])): ?>
                                    <img src="<?php echo $user['profile_picture']; ?>" alt="Profile Picture" class="profile-picture">
                                <?php endif; ?>
                                <?php echo $user['username']; ?>
                            </label>
                        </li>
                    <?php endif; ?>
                <?php endforeach; ?>
            </ul>
            <button type="submit" name="add_member">Add Member</button>
        </form>

        <!-- Remove Member Form -->
        <h3>Remove Member</h3>
        <form method="post">
            <ul class="checkbox-list">
                <?php foreach ($group['members'] as $memberId): ?>
                    <li class="checkbox-item">
                        <input type="checkbox" id="remove_<?php echo $memberId; ?>" name="members[]" value="<?php echo $memberId; ?>">
                        <label for="remove_<?php echo $memberId; ?>">
                            <?php if (isset($users[$memberId]['profile_picture'])): ?>
                                <img src="<?php echo $users[$memberId]['profile_picture']; ?>" alt="Profile Picture" class="profile-picture">
                            <?php endif; ?>
                            <?php echo $users[$memberId]['username']; ?>
                        </label>
                    </li>
                <?php endforeach; ?>
            </ul>
            <button type="submit" name="remove_member">Remove Member</button>
        </form>
        </form>
        <a href="index.php">Back to</a>
    </div>
</body>
</html>