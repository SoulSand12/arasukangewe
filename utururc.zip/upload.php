<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

$userId = $_SESSION['user_id'];
$uploadDir = 'uploads/';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['file'])) {
    $fileName = $_FILES['file']['name'];
    $fileTemp = $_FILES['file']['tmp_name'];

    if (move_uploaded_file($fileTemp, $uploadDir . $userId . '_' . $fileName)) {
        echo 'File uploaded successfully.';
    } else {
        echo 'Error uploading file.';
    }
}
?>
