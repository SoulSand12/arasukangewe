<?php
function respondToMessage($message) {
    // Ubah pesan menjadi huruf kecil untuk pencocokan yang tidak peka huruf besar/kecil
    $lowercaseMessage = strtolower($message);

    // Cek jika pesan mengandung kata "halo"
    if (strpos($lowercaseMessage, 'halo') !== false) {
        return "Halo juga!";
    }

    // Cek jika pesan mengandung kata "siapa namamu"
    if (strpos($lowercaseMessage, 'siapa namamu') !== false) {
        return "Saya adalah Bot!";
    }

    // Cek jika pesan mengandung kata "foto profil"
    if (strpos($lowercaseMessage, 'foto profil') !== false) {
        $botProfilePicture = 'bot/oreki.jpg'; // Gantilah dengan URL foto profil bot
        return "<img src='$botProfilePicture' alt='Profil Bot'>";
    }

    // Jika tidak ada kondisi khusus, kembalikan respons kosong atau default
    return "";
}

// Contoh penggunaan
if (isset($_POST['message'])) {
    $userMessage = $_POST['message'];
    $botResponse = respondToMessage($userMessage);

    // Hanya memberikan respons jika ada respons yang dihasilkan
    if (!empty($botResponse)) {
        echo $botResponse;
    }
}
?>
