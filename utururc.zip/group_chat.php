<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

$userId = $_SESSION['user_id'];
$users = json_decode(file_get_contents('users.json'), true);
$chatFile = 'public_chat.json';

$messages = json_decode(file_get_contents($chatFile), true);

// Generate a CSRF token
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

// Handling message sending
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['csrf_token']) && hash_equals($_SESSION['csrf_token'], $_POST['csrf_token']) && isset($_POST['message']) && !empty(trim($_POST['message']))) {
    $messageContent = htmlspecialchars($_POST['message']);
    $message = [
        'user_id' => $userId,
        'content' => $messageContent,
        'timestamp' => time(),
    ];

    if (isset($_FILES['image']) && $_FILES['image']['error'] === 0) {
        $targetDir = 'chat_images/';
        $imagePath = $targetDir . uniqid() . '_' . basename($_FILES['image']['name']);
        if (move_uploaded_file($_FILES['image']['tmp_name'], $imagePath)) {
            $message['image'] = $imagePath;
        }
    }

    $messages[] = $message;
    file_put_contents($chatFile, json_encode($messages, JSON_PRETTY_PRINT));

    // Invalidate the used CSRF token
    unset($_SESSION['csrf_token']);

    // Redirect to prevent form resubmission on page refresh
    header("Location: " . $_SERVER['PHP_SELF']);
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Public Chat</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }

        .chat-container {
            max-width: 600px;
            margin: auto;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            overflow: hidden;
            margin-top: 20px;
        }

        .chat-header {
            background-color: #3498db;
            color: #fff;
            padding: 10px;
            text-align: center;
            font-size: 18px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .chat-box {
            padding: 10px;
            overflow-y: auto;
            max-height: 300px;
            animation: fadeIn 0.5s ease;
        }

        .user-item {
            display: flex;
            align-items: center;
            border-bottom: 1px solid #ddd;
            padding: 10px;
        }

        .user-item img {
            width: 30px;
            height: 30px;
            margin-right: 10px;
            border-radius: 50%;
        }

        .user-item span {
            flex: 1;
        }

        .chat-form {
            display: flex;
            padding: 10px;
            background-color: #f1f1f1;
            animation: slideInUp 0.5s ease;
        }

        input[type="text"] {
            flex: 1;
            padding: 8px;
            margin-right: 8px;
        }

        button {
            padding: 8px;
            background-color: #3498db;
            color: #fff;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        @keyframes fadeIn {
            from {
                opacity: 0;
            }
            to {
                opacity: 1;
            }
        }

        @keyframes slideInUp {
            from {
                transform: translateY(50px);
            }
            to {
                transform: translateY(0);
            }
        }

        label {
            margin-right: 10px;
            cursor: pointer;
            color: #3498db;
        }

        #fileInput {
            display: none;
        }
    </style>
</head>
<body>
    <div class="chat-container">
        <div class="chat-header">
            Public Chat
        </div>
        <div class="chat-box" id="chatBox">
            <?php
            foreach ($messages as $message) {
                $senderName = $users[$message['user_id']]['username'];
                $senderProfilePicture = $users[$message['user_id']]['profile_picture'];
                $messageContent = $message['content'];
                $timestamp = date('H:i', $message['timestamp']);
                $imagePath = $message['image'] ?? null;

                echo "<div class='user-item'>";
                echo "<img src='$senderProfilePicture' alt='Profile Picture'>";
                echo "<span><strong>$senderName</strong>: $messageContent <em>($timestamp)</em></span>";
                if ($imagePath !== null) {
                    echo "<img src='$imagePath' alt='Sent Image' style='max-width: 100%; margin-top: 10px;'>";
                }
                echo "</div>";
            }
            ?>
        </div>
        <form method="post" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" enctype="multipart/form-data" class="chat-form">
            <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
            <input type="text" name="message" placeholder="Type your message..." required>
            <label for="fileInput">Attach Image</label>
            <input type="file" name="image" id="fileInput" accept="image/*">
            <button type="submit">Send</button>
        </form>
    </div>

    <script>
        // Scroll to the bottom of the chat box on page load
        var chatBox = document.getElementById('chatBox');
        chatBox.scrollTop = chatBox.scrollHeight;
    </script>
</body>
</html>
