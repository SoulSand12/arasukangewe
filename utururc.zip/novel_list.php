<?php
session_start();

// Redirect user to login page if not logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

// Load novel data from JSON file
$novelData = [];
if (file_exists('novel_data.json')) {
    $novelData = json_decode(file_get_contents('novel_data.json'), true);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Novel List</title>
<style>
    body {
        font-family: Arial, sans-serif;
        background-color: #f4f4f4;
        margin: 0;
        padding: 0;
    }

    .container {
        max-width: 800px;
        margin: 20px auto;
        padding: 20px;
        background-color: #fff;
        border-radius: 10px;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    }

    h2 {
        margin-top: 0;
        padding-top: 0;
    }

    .novel-list {
        list-style-type: none;
        padding: 0;
        margin: 0;
    }

    .novel-list li {
        margin-bottom: 10px;
    }

    .novel-list li a {
        display: block;
        padding: 10px;
        background-color: #fff;
        text-decoration: none;
        color: #333;
        border-radius: 5px;
        transition: background-color 0.3s ease;
    }

    .novel-list li a:hover {
        background-color: #f0f0f0;
    }

    .novel-list li img {
        margin-right: 10px;
        vertical-align: middle;
    }
    
    .create-novel-link {
        display: block;
        margin-top: 20px;
        text-align: center;
        text-decoration: none;
        color: #007bff;
    }

    .create-novel-link:hover {
        text-decoration: underline;
    }
</style>
</head>
<body>
    <div class="container">
        <h2>Your Novels</h2>
        <ul class="novel-list">
    <?php foreach ($novelData as $id => $novel): ?>
        <li>
            <a href="read_novel.php?id=<?php echo $id; ?>">
                <?php if (isset($novel['icon'])): ?>
                    <img src="<?php echo $novel['icon']; ?>" alt="Novel Icon" style="width: 50px; height: 50px; border-radius: 50%;">
                <?php endif; ?>
                <span><?php echo $novel['judul']; ?></span>
            </a>
        </li>
    <?php endforeach; ?>
</ul>
        <a href="create_novel.php">Create Your Novel</a> ||
        <a href="beranda.php">Back To beranda</a>
    </div>
</body>
</html>