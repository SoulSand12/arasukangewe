<?php
session_start();

// Memeriksa apakah pengguna sudah login
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

// Mendapatkan ID pengguna dari sesi
$userId = $_SESSION['user_id'];

// Memuat informasi pengguna dari file JSON
$users = json_decode(file_get_contents('users.json'), true);

// File untuk menyimpan pesan chat
$chatFile = 'public_chat.json';

// Memproses pengiriman pesan baru jika metode request adalah POST
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['message']) && !empty(trim($_POST['message']))) {
    // Mendapatkan pesan dari formulir dan membersihkannya
    $message = htmlspecialchars($_POST['message']);
    $timestamp = time();

    // Data pesan yang akan disimpan
    $messageData = [
        'sender_id' => $userId,
        'message' => $message,
        'timestamp' => $timestamp,
    ];

    // Memproses pengiriman gambar jika ada yang diunggah
    if ($_FILES['image']['error'] === 0) {
        $targetDir = 'chat_images/';
        $imagePath = $targetDir . uniqid() . '_' . basename($_FILES['image']['name']);
        move_uploaded_file($_FILES['image']['tmp_name'], $imagePath);
        $messageData['image'] = $imagePath;
    }

    // Memuat pesan yang sudah ada dari file JSON
    $messages = json_decode(file_get_contents($chatFile), true);
    $messages[] = $messageData;

    // Menyimpan kembali semua pesan ke file JSON
    file_put_contents($chatFile, json_encode($messages, JSON_PRETTY_PRINT));
}

// Memuat kembali semua pesan setelah memperbarui file JSON
$messages = json_decode(file_get_contents($chatFile), true);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Public Chat</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }

        .chat-container {
            max-width: 800px;
            margin: auto;
            padding: 20px;
            background-color: #fff;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
            margin-top: 50px;
        }

        .chat-header {
            background-color: #3498db;
            color: #fff;
            padding: 10px;
            text-align: center;
            font-size: 20px;
            border-radius: 8px 8px 0 0;
        }

        .chat-box {
            background-color: #fff;
            border: 1px solid #ddd;
            padding: 15px;
            border-radius: 0 0 8px 8px;
            margin-top: 15px;
            max-height: 400px;
            overflow-y: auto;
        }

        .input-container {
            display: flex;
            margin-top: 15px;
        }

        .message-input {
            flex: 1;
            padding: 10px;
            box-sizing: border-box;
            border: 1px solid #ddd;
            border-radius: 4px;
            margin-right: 10px;
        }

        .send-button {
            background-color: #3498db;
            color: #fff;
            padding: 10px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        .send-button:hover {
            background-color: #2980b9;
        }

        #fileInput {
            display: none;
        }

        label {
            margin-left: 10px;
            cursor: pointer;
            color: #3498db;
        }

        .message-container {
            display: flex;
            flex-direction: column;
        }

        .message {
            max-width: 70%;
            margin-bottom: 15px;
            border-radius: 8px;
            overflow: hidden;
            word-wrap: break-word;
            display: flex;
            align-items: flex-start;
        }

        .profile-picture-container {
            width: 40px;
            height: 40px;
            overflow: hidden;
            border-radius: 50%;
            margin-right: 10px;
        }

        .profile-picture {
            width: 100%;
            height: auto;
            border-radius: 50%;
        }

        .message-content {
            padding: 10px;
            display: flex;
            flex-direction: column;
        }

        .message.sent {
            align-self: flex-end;
            background-color: #3498db;
            color: #fff;
            align-items: flex-end;
        }

        .message.received {
            align-self: flex-start;
            background-color: #f1f1f1;
            color: #333;
            align-items: flex-start;
        }

        .message img {
            width: 100%;
            border-radius: 8px;
            margin-top: 10px;
        }

        .message strong {
            display: block;
            margin-bottom: 5px;
            color: #3498db;
        }

        .message span {
            white-space: pre-wrap;
        }

        .message span.timestamp {
            font-size: 12px;
            color: #888;
        }

        .back-button {
            background-color: #ddd;
            color: #333;
            padding: 10px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            text-decoration: none;
        }

        .back-button:hover {
            background-color: #ccc;
        }
    </style>
</head>
<body>
    <div class="chat-container">
        <div class="chat-header">
            Public Chat
        </div>
        <div class="chat-box" id="chatBox">
            <div class="message-container">
                <?php foreach ($messages as $message) : ?>
                    <?php
                    $senderId = $message['sender_id'];
                    $senderName = $users[$senderId]['username'];
                    $senderProfilePicture = $users[$senderId]['profile_picture'];
                    $messageContent = $message['message'];
                    $imagePath = isset($message['image']) ? $message['image'] : null;
                    $timestamp = date("H:i:s", $message['timestamp']);
                    $isSentByCurrentUser = ($senderId === $userId);
                    ?>
                    <div class="message <?= $isSentByCurrentUser ? 'sent' : 'received'; ?>">
                        <div class="profile-picture-container">
                            <img class="profile-picture" src="<?= $senderProfilePicture ?>" alt="Profile Picture">
                        </div>
                        <div class="message-content">
                            <strong><?= $senderName ?>:</strong>
                            <span><?= $messageContent ?></span>
                            <?php if ($imagePath) : ?>
                                <img src="<?= $imagePath ?>" alt="Sent Image">
                            <?php endif; ?>
                            <span class="timestamp"><?= $timestamp ?></span>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
        <form method="post" action="public_chat.php" enctype="multipart/form-data" class="input-container">
            <input type="text" name="message" id="message" class="message-input" placeholder="Type your message here...">
            <label for="fileInput">Attach Image</label>
            <input type="file" name="image" id="fileInput" accept="image/*">
            <button type="submit" class="send-button">Send</button>
        </form>
        <a href="index.php" class="back-button">Back to Chat</a>
    </div>

    <script>
        // Fungsi untuk memuat ulang chat box dengan pesan terbaru
        function updateChat() {
            fetch('get_chat_public.php')
                .then(response => response.json())
                .then(data => {
                    const chatBox = document.getElementById('chatBox');
                    chatBox.innerHTML = '';

                    const messageContainer = document.createElement('div');
                    messageContainer.classList.add('message-container');

                    data.messages.forEach(message => {
                        const senderName = message.senderName;
                        const messageContent = message.message;
                        const timestamp = message.timestamp;
                        const imagePath = message.imagePath;

                        const messageDiv = document.createElement('div');
                        messageDiv.classList.add('message');

                        const profilePictureContainer = document.createElement('div');
                        profilePictureContainer.classList.add('profile-picture-container');

                        const profilePicture = document.createElement('img');
                        profilePicture.src = message.senderProfilePicture;
                        profilePicture.alt = 'Profile Picture';
                        profilePicture.classList.add('profile-picture');

                        const messageContentDiv = document.createElement('div');
                        messageContentDiv.classList.add('message-content');
                        const senderNameElement = document.createElement('strong');
                        senderNameElement.textContent = `${senderName}:`;

                        const messageTextElement = document.createElement('span');
                        messageTextElement.textContent = ` ${messageContent}`;

                        const timestampElement = document.createElement('span');
                        timestampElement.textContent = ` ${timestamp}`;
                        timestampElement.classList.add('timestamp');

                        messageContentDiv.appendChild(senderNameElement);
                        messageContentDiv.appendChild(messageTextElement);

                        if (imagePath) {
                            const imageElement = document.createElement('img');
                            imageElement.src = imagePath;
                            imageElement.alt = 'Sent Image';
                            imageElement.classList.add('message-image');
                            messageContentDiv.appendChild(imageElement);
                        }

                        messageContentDiv.appendChild(timestampElement);

                        profilePictureContainer.appendChild(profilePicture);
                        messageDiv.appendChild(profilePictureContainer);
                        messageDiv.appendChild(messageContentDiv);

                        const isSentByCurrentUser = (message.senderId === <?= $userId ?>);
                        messageDiv.classList.add(isSentByCurrentUser ? 'sent' : 'received');

                        messageContainer.appendChild(messageDiv);
                    });

                    chatBox.appendChild(messageContainer);

                    // Scroll ke bawah setelah memuat pesan terbaru
                    chatBox.scrollTop = chatBox.scrollHeight;
                })
                .catch(error => console.error('Error updating chat:', error));
        }

        // Memuat ulang chat setiap 3 detik
        setInterval(updateChat, 3000);

        // Fungsi untuk mengirim pesan ke bot
        function sendMessageToBot(message) {
            fetch('bot.php', {
                method: 'POST',
                body: new URLSearchParams({ message: message }),
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded'
                }
            })
                .then(response => response.text())
                .then(botResponse => {
                    const chatBox = document.getElementById('chatBox');
                    const newMessageDiv = document.createElement('div');
                    newMessageDiv.innerHTML = botResponse;
                    chatBox.appendChild(newMessageDiv);

                    // Scroll ke bawah untuk melihat pesan bot terbaru
                    chatBox.scrollTop = chatBox.scrollHeight;
                })
                .catch(error => console.error('Error sending message to bot:', error));
        }

        // Event listener untuk pengiriman pesan (submit form)
        document.querySelector('form').addEventListener('submit', function(e) {
            e.preventDefault();
            const messageInput = document.getElementById('message');
            const message = messageInput.value.trim();

            if (message === '') return;

            // Membersihkan input setelah dikirim
            messageInput.value = '';

            // Mengirim pesan ke server
            const formData = new FormData();
            formData.append('message', message);

            fetch('public_chat.php', {
                method: 'POST',
                body: formData
            })
                .then(response => {
                    if (!response.ok) {
                        throw new Error('Network response was not ok');
                    }
                    // Pesan berhasil dikirim, perbarui chat
                    updateChat();
                    sendMessageToBot(message); // Opsional: mengirim pesan ke bot setelah ke server
                })
                .catch(error => console.error('Error sending message:', error));
        });
    </script>
</body>
</html>
 
