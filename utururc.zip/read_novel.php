<?php
session_start();

// Load novel data from JSON file
$novelData = [];
if (file_exists('novel_data.json')) {
    $novelData = json_decode(file_get_contents('novel_data.json'), true);
}

// Check if novel ID is provided in the URL
if (isset($_GET['id'])) {
    $novelId = $_GET['id'];

    // Check if the provided novel ID exists in the data
    if (isset($novelData[$novelId])) {
        // Get the novel details
        $novel = $novelData[$novelId];
    } else {
        // Redirect to novel list if novel ID is invalid
        header('Location: novel_list.php');
        exit();
    }
} else {
    // Redirect to novel list if novel ID is not provided
    header('Location: novel_list.php');
    exit();
}

// Check if form is submitted to navigate chapters
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Check if previous chapter button is clicked
    if (isset($_POST['prev_chapter'])) {
        // Check if current chapter index is greater than 0
        if ($_SESSION['current_chapter_index'] > 0) {
            // Decrement current chapter index
            $_SESSION['current_chapter_index']--;
        }
    }
    // Check if next chapter button is clicked
    elseif (isset($_POST['next_chapter'])) {
        // Check if current chapter index is less than the total number of chapters
        if ($_SESSION['current_chapter_index'] < count($novel['chapters']) - 1) {
            // Increment current chapter index
            $_SESSION['current_chapter_index']++;
        }
    }
}

// Set the session variable for the current chapter index
if (!isset($_SESSION['current_chapter_index'])) {
    $_SESSION['current_chapter_index'] = 0;
}

// Get the current chapter content
$currentChapterIndex = $_SESSION['current_chapter_index'];
$currentChapterContent = $novel['chapters'][$currentChapterIndex];

// Load user data from JSON file
$userData = [];
if (file_exists('users.json')) {
    $userData = json_decode(file_get_contents('users.json'), true);
}

// Get author's name
$authorName = isset($userData[$novel['author']]) ? $userData[$novel['author']]['username'] : 'Unknown Author';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Read Novel - <?php echo $novel['judul']; ?></title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }

        .container {
            max-width: 800px;
            margin: auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        h2 {
            text-align: center;
            margin-top: 0;
            padding-top: 10px;
        }

        .novel-content {
            padding: 20px;
            border-bottom: 1px solid #ccc;
        }

        .navigation-buttons {
            display: flex;
            justify-content: space-between;
            margin-top: 20px;
        }

        button {
            padding: 10px 20px;
            background-color: #3498db;
            color: #fff;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        button:hover {
            background-color: #2980b9;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Read Novel - <?php echo $novel['judul']; ?></h2>
        <!-- Novel Info -->
        <div class="novel-info">
            <div class="author-info">
                <?php if (isset($novel['icon'])): ?>
                    <img src="<?php echo $novel['icon']; ?>" alt="Novel Icon" style="width: 100px; height: auto;">
                <?php endif; ?>
                <div>
                    <p><strong>Judul:</strong> <?php echo $novel['judul']; ?></p>
                    <p><strong>Penulis:</strong> <?php echo $authorName; ?></p>
                    <p><strong>Jumlah Chapter:</strong> <?php echo count($novel['chapters']); ?></p>
                </div>
            </div>
        </div>
        <!-- Novel Content -->
        <div class="novel-content">
            <p><?php echo $currentChapterContent; ?></p>
        </div>
        <!-- Navigation Buttons -->
        <div class="navigation-buttons">
            <form method="post">
                <button type="submit" name="prev_chapter">Previous Chapter</button>
            </form>
            <form method="post">
                <button type="submit" name="next_chapter">Next Chapter</button>
            </form>
        </div>
    </div>
    <!-- Button to go back to novel list -->
<div style="text-align: center; margin-top: 20px;">
    <a href="novel_list.php" style="display: inline-block; padding: 10px 20px; background-color: #3498db; color: #fff; text-decoration: none; border-radius: 4px;">Back to Novel List</a>
</div>
</body>
</html>