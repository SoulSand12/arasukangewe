<?php
session_start();

function getUsers() {
    $usersJson = file_get_contents('users.json');
    return json_decode($usersJson, true);
}

function saveUsers($users) {
    $usersJson = json_encode($users, JSON_PRETTY_PRINT);
    file_put_contents('users.json', $usersJson);
}

function isUsernameTaken($username) {
    $users = getUsers();
    foreach ($users as $user) {
        if ($user['username'] === $username) {
            return true;
        }
    }
    return false;
}

function register($username, $password, $profilePicture) {
    if (!isUsernameTaken($username)) {
        $users = getUsers();
        $newUserId = uniqid();
        
        $users[$newUserId] = [
            'username' => $username,
            'password' => $password,
            'profile_picture' => $profilePicture,
            'friend_request' => [],
            'friend_addRequest' => [],
            'friend' => []
        ];
        saveUsers($users);

        // Redirect to beranda.php after successful registration
        $_SESSION['user_id'] = $newUserId;
        header('Location: beranda.php');
        exit();
    }

    return null;
}

if (isset($_SESSION['user_id'])) {
    header('Location: beranda.php');
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['register'])) {
    $newUsername = htmlspecialchars($_POST['new_username']);
    $newPassword = $_POST['new_password'];

    // Handle file upload for profile picture
    $targetDir = 'uploads/';
    $profilePicture = $targetDir . basename($_FILES['profile_picture']['name']);

    // Move the uploaded file
    if (move_uploaded_file($_FILES['profile_picture']['tmp_name'], $profilePicture)) {
        $newUserId = register($newUsername, $newPassword, $profilePicture);

        if ($newUserId !== null) {
            // Registration is now handled inside the register function
        }
    } else {
        echo "<p>Failed to upload profile picture.</p>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }

        h2 {
            color: #3498db;
        }

        form {
            max-width: 400px;
            margin: 20px auto;
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        label {
            display: block;
            margin-bottom: 8px;
            color: #333;
        }

        input {
            width: 100%;
            padding: 10px;
            box-sizing: border-box;
            margin-bottom: 15px;
            border: 1px solid #ddd;
            border-radius: 4px;
        }

        button {
            background-color: #3498db;
            color: #fff;
            padding: 10px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            width: 100%;
        }

        button:hover {
            background-color: #2980b9;
        }
    </style>
</head>
<body>
    <form method="post" action="register.php" enctype="multipart/form-data">
        <h2>Register</h2>
        <label for="new_username">New Username:</label>
        <input type="text" name="new_username" id="new_username" required>
        <label for="new_password">New Password:</label>
        <input type="password" name="new_password" id="new_password" required>
        <label for="profile_picture">Profile Picture:</label>
        <input type="file" name="profile_picture" id="profile_picture" accept="image/*" required>
        <button type="submit" name="register">Register</button>
    </form>
</body>
</html>
