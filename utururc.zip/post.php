<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

$userId = $_SESSION['user_id'];

$users = json_decode(file_get_contents('users.json'), true);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $message = htmlspecialchars($_POST['message']);
    $timestamp = time();
    $postImages = [];
    $postVideos = [];

    // Process multiple images
    if (!empty(array_filter($_FILES['post_images']['name']))) {
        $targetDir = 'post/';
        foreach ($_FILES['post_images']['tmp_name'] as $key => $tmp_name) {
            $postImage = $targetDir . uniqid() . '_' . basename($_FILES['post_images']['name'][$key]);
            move_uploaded_file($tmp_name, $postImage);
            $postImages[] = $postImage;
        }
    }

    // Process multiple videos
    if (!empty(array_filter($_FILES['post_videos']['name']))) {
        $targetDir = 'post/';
        foreach ($_FILES['post_videos']['tmp_name'] as $key => $tmp_name) {
            $postVideo = $targetDir . uniqid() . '_' . basename($_FILES['post_videos']['name'][$key]);
            move_uploaded_file($tmp_name, $postVideo);
            $postVideos[] = $postVideo;
        }
    }

    // Get selected categories
    $categories = $_POST['categories'] ?? [];

    $posts = json_decode(file_get_contents('postingan.json'), true);
    $postId = uniqid();
    $likes = [];
    $comments = [];

    $posts[] = [
        'post_id' => $postId,
        'sender_id' => $userId,
        'message' => $message,
        'images' => $postImages,
        'videos' => $postVideos,
        'timestamp' => $timestamp,
        'like' => $likes,
        'comment' => $comments,
        'categories' => $categories,
    ];

    file_put_contents('postingan.json', json_encode($posts, JSON_PRETTY_PRINT));

    // Redirect to avoid form resubmission on refresh
    header('Location: beranda.php');
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Upload Postingan</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }

        .upload-container {
            max-width: 600px;
            margin: auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            margin-top: 50px;
        }

        .upload-form {
            display: flex;
            flex-direction: column;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            font-weight: bold;
            margin-bottom: 10px;
        }

        .form-group input[type="file"] {
            width: 100%;
            padding: 10px;
            box-sizing: border-box;
            margin-top: 5px; /* Adjust spacing */
        }

        .form-group textarea {
            width: 100%;
            height: 100px;
            padding: 10px;
            box-sizing: border-box;
            margin-top: 5px; /* Adjust spacing */
        }

        .form-group button {
            background-color: #3498db;
            color: #fff;
            padding: 10px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        .form-group button:hover {
            background-color: #2980b9;
        }

        /* Category Text Colors */
        .category-meme { color: #FF5733; }
        .category-quotes { color: #9B59B6; }
        .category-darkmeme { color: #34495E; }
        .category-foryoupage { color: #27AE60; }
        .category-random { color: #E67E22; }
    </style>
</head>
<body>
    <div class='upload-container'>
        <h2>Upload Postingan</h2>
        <form method='post' action='post.php' enctype='multipart/form-data' class='upload-form'>
            <div class='form-group'>
                <label for='message'>Kata-kata:</label>
                <textarea name='message' id='message' placeholder='Tulis pesanmu...'></textarea>
            </div>
            <div class='form-group'>
                <label for='post_images'>Unggah Gambar (multiple):</label>
                <input type='file' name='post_images[]' id='post_images' accept='image/*' multiple>
            </div>
            <div class='form-group'>
                <label for='post_videos'>Unggah Video (multiple):</label>
                <input type='file' name='post_videos[]' id='post_videos' accept='video/*' multiple>
            </div>
            <div class='form-group'>
                <label>Pilih Kategori:</label>
                <input type='checkbox' name='categories[]' value='meme'>
                <label for='meme' class='category-meme'>Meme</label><br>
                <input type='checkbox' name='categories[]' value='quotes'>
                <label for='quotes' class='category-quotes'>Quotes</label><br>
                <input type='checkbox' name='categories[]' value='darkmeme'>
                <label for='darkmeme' class='category-darkmeme'>Dark Meme</label><br>
                <input type='checkbox' name='categories[]' value='foryoupage'>
                <label for='foryoupage' class='category-foryoupage'>For You Page</label><br>
                <input type='checkbox' name='categories[]' value='random'>
                <label for='random' class='category-random'>Random</label>
            </div>
            <div class='form-group'>
                <button type='submit'>Upload</button>
            </div>
        </form>
    </div>
</body>
</html>