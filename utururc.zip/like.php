<?php
session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['post_id'])) {
    $postId = $_POST['post_id'];
    $userId = $_SESSION['user_id'];

    // Load posts
    $posts = json_decode(file_get_contents('postingan.json'), true);

    foreach ($posts as &$post) {
        if ($post['post_id'] === $postId) {
            // Cek apakah user sudah like sebelumnya
            $userLikedIndex = array_search($userId, $post['like']);
            if ($userLikedIndex === false) {
                // User belum like, tambahkan ke likes
                $post['like'][] = $userId;
            } else {
                // User sudah like, kita remove untuk implementasi dislike
                array_splice($post['like'], $userLikedIndex, 1);
            }

            // Update like count
            $likeCount = count($post['like']);
            $post['like_count'] = $likeCount;

            break;
        }
    }

    // Simpan perubahan ke postingan.json
    file_put_contents('postingan.json', json_encode($posts, JSON_PRETTY_PRINT));
}
