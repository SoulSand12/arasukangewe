<?php
session_start();

// Check if the user is logged in, if not, redirect to login page
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

// Get the user ID from the session
$userId = $_SESSION['user_id'];

// Load user and group data from JSON files
$users = json_decode(file_get_contents('users.json'), true);
$groups = json_decode(file_get_contents('groups.json'), true);

// Function to find or create a private chat room
function findPrivateChatRoom($privateChats, $userId, $otherUserId) {
    foreach ($privateChats as $roomId => $chatData) {
        $members = $chatData['members'] ?? [];
        // Check if the room already exists for the given users
        if (in_array($userId, $members) && in_array($otherUserId, $members)) {
            return $roomId;
        }
    }
    // If no existing room found, create a new room
    $newRoomId = uniqid();
    $privateChats[$newRoomId] = [
        'members' => [$userId, $otherUserId],
        'chat' => [],
    ];
    // Save updated private chat data
    file_put_contents('private_chat_db/chat_private_data.json', json_encode($privateChats, JSON_PRETTY_PRINT));
    return $newRoomId;
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Chat App</title>
    <style>
        /* Add or modify styles as needed */
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }

        .chat-container {
            max-width: 800px;
            margin: auto;
            padding: 20px;
            background-color: #fff;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
            margin-top: 50px;
        }

        .chat-header {
            background-color: #3498db;
            color: #fff;
            padding: 10px;
            text-align: center;
            font-size: 20px;
            border-radius: 8px 8px 0 0;
        }

        .chat-box {
            padding: 10px;
        }

        .user-item, .group-item {
            display: flex;
            align-items: center;
            border-bottom: 1px solid #ddd;
            padding: 10px;
            cursor: pointer;
        }

        .user-item a, .group-item a {
            display: flex;
            align-items: center;
            text-decoration: none;
            color: #333;
            width: 100%;
        }

        .user-item img, .group-item img {
            width: 30px;
            height: 30px;
            margin-right: 10px;
            border-radius: 50%;
        }

        .user-item span, .group-item span {
            flex: 1;
        }

        .chat-form {
            display: flex;
            padding: 10px;
            background-color: #f1f1f1;
            animation: slideInUp 0.5s ease;
        }

        button {
            flex: 1;
            padding: 8px;
            background-color: #3498db;
            color: #fff;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        @keyframes fadeIn {
            from {
                opacity: 0;
            }
            to {
                opacity: 1;
            }
        }

        @keyframes slideInUp {
            from {
                transform: translateY(50px);
            }
            to {
                transform: translateY(0);
            }
        }
    </style>
</head>
<body>
    <div class="chat-container">
        <div class="chat-header">
            Welcome, <?php echo $users[$userId]['username']; ?>!
            <a href="beranda.php">Beranda</a>
        </div>
        <div class="chat-box">
            <?php
            // Loop through users
            foreach ($users as $otherUserId => $otherUser) {
                // Skip the logged-in user
                if ($otherUserId == $userId) {
                    continue;
                }
                // Get the latest message for the user
                $latestMessage = "Pesan terbaru dari $otherUser[username]";
                // Display the user item with a link to private chat
                echo "<div class='user-item'>";
                echo "<a href='private_chat.php?room_id=" . findPrivateChatRoom([], $userId, $otherUserId) . "'>";
                echo "<img src='$otherUser[profile_picture]' alt='Profile Picture'>";
                echo "<span>$otherUser[username]</span>";
                echo "<span>$latestMessage</span>";
                echo "</a>";
                echo "</div>";
            }

            // Check if the user is a member of any group
            foreach ($groups as $groupId => $group) {
                if (in_array($userId, $group['members'])) {
                    // Display group information
                    $groupImage = $group['group_picture'] ?? 'default_group_image.jpg';
                    echo "<div class='group-item'>";
                    echo "<a href='group_chat.php?group_id=$groupId'>";
                    echo "<img src='$groupImage' alt='Group Image'>";
                    echo "<span>$group[group_name]</span>";
                    echo "<span>Group Chat</span>";
                    echo "</a>";
                    echo "</div>";
                }
            }
            ?>
        </div>
        <form method='post' action='index.php' class='chat-form'>
            <button type='submit' formaction='create_group.php'>Buat Grup</button>
        </form>
        <form method='post' action='index.php' class='chat-form'>
            <button type='submit' formaction='public_chat.php'>Group Chat</button>
        </form>
        <a href="beranda.php">Kembali ke Beranda</a>
    </div>
    <script>
        // Your JavaScript code here
    </script>
</body>
</html>