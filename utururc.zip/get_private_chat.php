<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    header('Content-Type: application/json');
    echo json_encode(['error' => 'User not authenticated']);
    exit();
}

$userId = $_SESSION['user_id'];
$roomId = $_GET['room_id'] ?? null;

if (!$roomId) {
    header('Content-Type: application/json');
    echo json_encode(['error' => 'Room ID not provided']);
    exit();
}

// Fetch private chat data
$privateChats = json_decode(file_get_contents('private_chat_db/chat_private_data.json'), true);
$chatData = $privateChats[$roomId] ?? null;

// Check if the user is a member of the specified private chat room
if (!$chatData || !in_array($userId, $chatData['members'])) {
    header('Content-Type: application/json');
    echo json_encode(['error' => 'User not authorized for this room']);
    exit();
}

// Fetch existing messages in the private chat room
$messages = $chatData['chat'] ?? [];

// Prepare an array for the latest messages
$latestMessages = [];

foreach ($messages as $message) {
    $senderId = $message['sender_id'];
    $senderName = $users[$senderId]['username'];
    $senderProfilePicture = $users[$senderId]['profile_picture'];
    $messageContent = $message['message'];
    $timestamp = date("H:i:s", $message['timestamp']);

    // Build the message data
    $messageData = [
        'sender_name' => $senderName,
        'sender_profile_picture' => $senderProfilePicture,
        'message_content' => $messageContent,
        'timestamp' => $timestamp,
    ];

    // Add the message data to the array
    $latestMessages[] = $messageData;
}

// Output the latest messages as JSON
header('Content-Type: application/json');
echo json_encode($latestMessages, JSON_PRETTY_PRINT);
exit();
?>
