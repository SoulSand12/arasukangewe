<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

$userId = $_SESSION['user_id'];
$users = json_decode(file_get_contents('users.json'), true);
$posts = json_decode(file_get_contents('postingan.json'), true);

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['post_id'])) {
    $postId = $_POST['post_id'];

    foreach ($posts as &$post) {
        if ($post['post_id'] == $postId) {
            if (!isset($post['like'])) {
                $post['like'] = [];
            }

            if (in_array($userId, $post['like'])) {
                // Remove like
                $post['like'] = array_diff($post['like'], [$userId]);
            } else {
                // Add like
                $post['like'][] = $userId;
            }

            file_put_contents('postingan.json', json_encode($posts, JSON_PRETTY_PRINT));
            echo json_encode(['liked' => in_array($userId, $post['like'])]);
            exit();
        }
    }
}

// Acak urutan postingan
shuffle($posts);

// Daftar kategori dengan warna teks yang sesuai
$categoryColors = [
    'meme' => '#FF5733',
    'quotes' => '#9B59B6',
    'darkmeme' => '#34495E',
    'foryoupage' => '#27AE60',
    'random' => '#E67E22'
];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Beranda</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }

        .beranda-container {
            max-width: 800px;
            margin: auto;
            padding: 20px;
            padding-top: 60px; /* Adding padding for header */
        }

        .beranda-header {
            background-color: #3498db;
            color: #fff;
            padding: 10px;
            text-align: center;
            font-size: 18px;
            position: fixed;
            top: 0;
            width: 100%;
            z-index: 1000;
        }

        .profile-section,
        .post {
            background-color: #fff;
            border: 1px solid #ddd;
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 15px;
        }

        .profile-picture {
            width: 40px;
            height: 40px;
            margin-right: 10px;
            border-radius: 50%;
        }

        .post-images-container {
            display: flex;
            flex-wrap: wrap;
            justify-content: space-between;
            margin-top: 10px;
        }

        .post-image {
            width: 48%;
            margin-bottom: 10px;
        }

        .post-video {
            max-width: 100%;
            height: auto;
            margin-top: 10px;
        }

        .post-actions {
            display: flex;
            justify-content: space-between;
            margin-top: 10px;
        }

        .like-button,
        button {
            background-color: #3498db;
            color: #fff;
            padding: 10px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        .like-button:hover,
        button:hover {
            background-color: #2980b9;
        }

        .post-time {
            color: #777;
            font-size: 12px;
        }

        .category {
            font-weight: bold;
            margin-right: 5px;
        }

        /* Side Panel */
        .side-panel {
            height: 100%;
            width: 0;
            position: fixed;
            z-index: 1000;
            top: 0;
            left: 0;
            background-color: #3498db;
            overflow-x: hidden;
            transition: 0.5s;
            padding-top: 60px;
        }

        .side-panel a {
            padding: 8px 8px 8px 32px;
            text-decoration: none;
            font-size: 25px;
            color: #fff;
            display: block;
            transition: 0.3s;
        }

        .side-panel a:hover {
            background-color: #2980b9;
        }

        .side-panel .close-btn {
            position: absolute;
            top: 20px;
            left: 25px; /* Adjusted left position */
            font-size: 36px;
            cursor: pointer;
            color: #fff;
            transition: 0.3s;
        }

        .side-panel .close-btn:hover {
            color: #ccc;
        }

        /* Responsive */
        @media screen and (max-height: 450px) {
            .side-panel {padding-top: 15px;}
            .side-panel a {font-size: 18px;}
        }
    </style>
</head>
<body>
    <div id="mySidepanel" class="side-panel">
        <span class="close-btn" onclick="closePanel()">&times;</span> <!-- Close button added -->
        <a href="beranda.php">Beranda</a>
        <a href="profile.php">Profil</a>
        <a href="index.php">Chat</a>
        <a href="post.php">Post</a>
        <a href="friends.php">Friends</a>
        <a href="novel_list.php">Novel</a>
    </div>

    <div class="beranda-header">
        <span style="font-size:30px;cursor:pointer;position:absolute;left:10px;top:10px;" onclick="openPanel()">&#9776;</span>
        <span>Beranda</span>
    </div>

    <div class='beranda-container'>
        <?php
        $userProfilePicture = $users[$userId]['profile_picture'];
        echo "<div class='profile-section'>";
        echo "<div class='profile-info'>";
        echo "<img src='$userProfilePicture' alt='Profile Picture' class='profile-picture'>";
        echo "<strong>" . $users[$userId]['username'] . ":</strong>";
        echo "</div>";
        echo "<a href='post.php'>Apa yang Anda pikirkan?</a>";
        echo "</div>";

        foreach ($posts as $post) {
            $postId = $post['post_id'];
            $senderId = $post['sender_id'];
            $senderName = $users[$senderId]['username'];
            $senderProfilePicture = $users[$senderId]['profile_picture'];
            $postContent = $post['message'];
            $postImages = $post['images'] ?? [];
            $postVideos = $post['videos'] ?? [];
            $postCategories = $post['categories'] ?? [];
            $likes = isset($post['like']) ? $post['like'] : [];
            $likeCount = count($likes);
            $postTime = date("F j, Y, g:i a", $post['timestamp']);

            echo "<div class='post'>";
            echo "<div class='profile-info'>";
            echo "<img src='$senderProfilePicture' alt='Profile Picture' class='profile-picture'>";
            echo "<strong>$senderName:</strong>";
            echo "</div>";

            if ($senderId === $userId) {
                echo "<div class='edit-button'>";
                echo "<a href='edit_post.php?post_id=$postId'>Edit</a>";
                echo "</div>";
            }

            if (!empty($postCategories)) {
                echo "<div class='post-categories'>";
                foreach ($postCategories as $category) {
                    echo "<span class='category' style='color: " . $categoryColors[$category] . ";'>#$category</span>";
                }
                echo "</div>";
            }

            echo "<div class='post-images-container'>";
            foreach ($postImages as $postImage) {
                echo "<img src='$postImage' alt='Posted Image' class='post-image'>";
            }
            echo "</div>";

            foreach ($postVideos as $postVideo) {
                echo "<video controls class='post-video'>";
                echo "<source src='$postVideo' type='video/mp4'>";
                echo "Your browser does not support the video tag.";
                echo "</video>";
            }

            echo "<div class='post-content'>";
            echo "<p>$postContent</p>";
            echo "<div class='post-actions'>";
            echo "<button class='like-button' data-post-id='$postId'>Like (<span class='like-count'>$likeCount</span>)</button>";
            echo "<a href='komentar.php?post_id=$postId'>Komentar</a>";
            echo "</div>";
            echo "<div class='post-time'>$postTime</div>";
            echo "</div>";

            echo "</div>";
        }
        ?>
    </div>

    <script>
        function openPanel() {
            document.getElementById("mySidepanel").style.width = "250px";
        }

        function closePanel() {
            document.getElementById("mySidepanel").style.width = "0";
        }
        
        document.querySelectorAll('.like-button').forEach(button => {
            button.addEventListener('click', async () => {
                const postId = button.getAttribute('data-post-id');
                const response = await fetch('beranda.php', {
                    method: 'POST',
                    body: new URLSearchParams({ post_id: postId }),
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded'
                    }
                });

                if (response.ok) {
                    const data = await response.json();
                    const likeCountElement = button.querySelector('.like-count');
                    const currentCount = parseInt(likeCountElement.innerText);
                    const newCount = data.liked ? currentCount + 1 : currentCount - 1;
                    likeCountElement.innerText = newCount;
                }
            });
        });
    </script>
</body>
</html>

