<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

$userId = $_SESSION['user_id'];
$users = json_decode(file_get_contents('users.json'), true);

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['group_name'])) {
    $groupName = htmlspecialchars($_POST['group_name']);
    $groupMembers = isset($_POST['group_members']) ? $_POST['group_members'] : [];
    $timestamp = time();

    // Create a unique group ID
    $groupId = uniqid('group_', true);

    $groupPicture = null;

    // Check if a file is uploaded
    if (isset($_FILES['group_picture']) && $_FILES['group_picture']['error'] === UPLOAD_ERR_OK) {
        $uploadDir = 'db_group/';
        $uploadFile = $uploadDir . basename($_FILES['group_picture']['name']);

        // Move uploaded file to the specified directory
        if (move_uploaded_file($_FILES['group_picture']['tmp_name'], $uploadFile)) {
            $groupPicture = $uploadFile;
        } else {
            // Handle file upload error
            echo "Failed to upload group picture.";
        }
    }

    // Create an array to store group information
    $groupData = [
        'group_id' => $groupId,
        'group_name' => $groupName,
        'admin_id' => $userId,
        'timestamp' => $timestamp,
        'members' => [$userId],  // Include the group creator by default
        'group_picture' => $groupPicture,
        'messages' => []
    ];

    // Add selected members to the group
    foreach ($groupMembers as $memberId) {
        if ($memberId != $userId && isset($users[$memberId])) {
            $groupData['members'][] = $memberId;
        }
    }

    // Save group data
    $groups = json_decode(file_get_contents('groups.json'), true);
    $groups[] = $groupData;
    file_put_contents('groups.json', json_encode($groups, JSON_PRETTY_PRINT));

    // Redirect to avoid form resubmission on refresh
    header('Location: index.php');
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Group</title>
    <style>
body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }

        .group-container {
            max-width: 600px;
            margin: auto;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            overflow: hidden;
        }

        .group-header {
            background-color: #3498db;
            color: #fff;
            padding: 10px;
            text-align: center;
            font-size: 18px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .group-header a {
            color: #fff;
            text-decoration: none;
        }

        .group-form {
            padding: 20px;
            background-color: #f1f1f1;
        }

        label {
            display: block;
            margin-bottom: 10px;
        }

        input[type="text"] {
            width: 100%;
            padding: 8px;
            border: 1px solid #ddd;
            border-radius: 4px;
            margin-bottom: 10px;
        }

        input[type="checkbox"] {
            margin-right: 5px;
        }

        .user-list {
            list-style-type: none;
            padding: 0;
        }

        .user-item {
            display: flex;
            align-items: center;
            border-bottom: 1px solid #ddd;
            padding: 10px;
            cursor: pointer;
        }

        .user-item img {
            width: 30px;
            height: 30px;
            margin-right: 10px;
            border-radius: 50%;
        }

        button {
            padding: 8px;
            background-color: #3498db;
            color: #fff;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        button:hover {
            background-color: #2980b9;
        }
    </style>
</head>
<body>
    <div class="group-container">
        <div class="group-header">
            <a href="index.php">Kembali</a>
            <span>Create Group</span>
        </div>
        <form method="post" action="create_group.php" enctype="multipart/form-data" class="group-form">
            <label for="group_name">Nama Group:</label>
            <input type="text" name="group_name" id="group_name" required>

            <label for="group_picture">Foto Profil Group:</label>
            <input type="file" name="group_picture" accept="image/*">

            <label>Pilih Anggota:</label>
            <ul class="user-list">
                <?php
                foreach ($users as $otherUserId => $otherUser) {
                    if ($otherUserId == $userId) {
                        continue;
                    }
                    echo "<li class='user-item'>";
                    echo "<input type='checkbox' name='group_members[]' value='$otherUserId'>";
                    echo "<img src='$otherUser[profile_picture]' alt='Profile Picture'>";
                    echo "<span>$otherUser[username]</span>";
                    echo "</li>";
                }
                ?>
            </ul>

            <button type="submit">Buat Group</button>
        </form>
    </div>
</body>
</html>
