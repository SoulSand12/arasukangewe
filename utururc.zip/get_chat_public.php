<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

$userId = $_SESSION['user_id'];
$users = json_decode(file_get_contents('users.json'), true);
$chatFile = 'public_chat.json';

$messages = json_decode(file_get_contents($chatFile), true);

$outputMessages = [];

foreach ($messages as $message) {
    $senderId = $message['sender_id'];
    $senderName = $users[$senderId]['username'];
    $senderProfilePicture = $users[$senderId]['profile_picture'];
    $messageContent = $message['message'];
    $imagePath = $message['image'] ?? null;
    $timestamp = date("H:i:s", $message['timestamp']);

    $outputMessages[] = [
        'sender' => [
            'userId' => $senderId,
            'username' => $senderName,
            'profilePicture' => $senderProfilePicture,
        ],
        'content' => $messageContent,
        'timestamp' => $timestamp,
        'imagePath' => $imagePath,
    ];
}

echo json_encode(['messages' => $outputMessages]);
?>
