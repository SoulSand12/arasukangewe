<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

$userId = $_SESSION['user_id'];
$users = json_decode(file_get_contents('users.json'), true);
$posts = json_decode(file_get_contents('postingan.json'), true);

// Ambil post_id dari query parameter
if (isset($_GET['post_id'])) {
    $postIdToDisplay = $_GET['post_id'];

    // Temukan postingan dengan post_id yang sesuai
    $selectedPost = null;
    foreach ($posts as $post) {
        if ($post['post_id'] === $postIdToDisplay) {
            $selectedPost = $post;
            break;
        }
    }
} else {
    // Jika tidak ada post_id, kembali ke beranda
    header('Location: beranda.php');
    exit();
}

// Simulasikan data komentar dari postingan
$komentarData = isset($selectedPost['komentar']) ? $selectedPost['komentar'] : [];

// Handle penambahan komentar
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['komentar'])) {
    $newKomentar = [
        'user_id' => $userId,
        'komentar' => $_POST['komentar'],
        'gambar' => null,
    ];

    // Handle unggah gambar
    if (isset($_FILES['gambar']) && $_FILES['gambar']['error'] === UPLOAD_ERR_OK) {
        $uploadDir = 'komentargambar/';
        $uploadFile = $uploadDir . basename($_FILES['gambar']['name']);
        
        // Pindahkan file yang diunggah ke direktori yang ditentukan
        move_uploaded_file($_FILES['gambar']['tmp_name'], $uploadFile);
        
        $newKomentar['gambar'] = $uploadFile;
    }

    // Simpan komentar baru ke data postingan
    $selectedPost['komentar'][] = $newKomentar;

    // Simpan data postingan kembali ke file
    foreach ($posts as &$post) {
        if ($post['post_id'] === $postIdToDisplay) {
            $post = $selectedPost;
            break;
        }
    }

    file_put_contents('postingan.json', json_encode($posts, JSON_PRETTY_PRINT));
    
    // Redirect untuk menghindari resubmission form saat refresh
    header("Location: komentar.php?post_id=$postIdToDisplay");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Komentar</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }

        .komentar-container {
            max-width: 800px;
            margin: auto;
            padding: 20px;
        }

        .komentar-header {
            background-color: #3498db;
            color: #fff;
            padding: 10px;
            text-align: center;
            font-size: 18px;
            margin-bottom: 20px;
        }

        .komentar-item {
            background-color: #fff;
            border: 1px solid #ddd;
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 15px;
        }

        .profile-picture {
            width: 40px;
            height: 40px;
            margin-right: 10px;
            border-radius: 50%;
        }

        .form-container {
            background-color: #fff;
            border: 1px solid #ddd;
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
        }

        textarea {
            width: 100%;
            margin-bottom: 10px;
        }

        input[type="file"] {
            margin-bottom: 10px;
        }

        input[type="submit"] {
            background-color: #3498db;
            color: #fff;
            padding: 10px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        input[type="submit"]:hover {
            background-color: #2980b9;
        }

        img {
            max-width: 100%;
            height: auto;
            margin-top: 10px;
        }
    </style>
</head>
<body>
    <div class='komentar-container'>
        <div class='komentar-header'>
            <a href="beranda.php">Kembali ke Beranda</a>
        </div>

        <?php
        foreach ($komentarData as $komentar) {
            $komentarUserId = $komentar['user_id'];
            $komentarUsername = $users[$komentarUserId]['username'];
            $komentarProfilePicture = $users[$komentarUserId]['profile_picture'];
            $komentarContent = $komentar['komentar'];
            $komentarImage = $komentar['gambar'];

            echo "<div class='komentar-item'>";
            echo "<div class='profile-info'>";
            echo "<img src='$komentarProfilePicture' alt='Profile Picture' class='profile-picture'>";
            echo "<strong>$komentarUsername:</strong>";
            echo "</div>";

            if ($komentarImage !== null && file_exists($komentarImage)) {
                echo "<img src='$komentarImage' alt='Komentar Image'>";
            }

            echo "<p>$komentarContent</p>";
            echo "</div>";
        }
        ?>

        <!-- Formulir untuk menambahkan komentar baru -->
        <div class="form-container">
            <form method="post" enctype="multipart/form-data">
                <textarea name="komentar" placeholder="Tambahkan komentar..."></textarea>
                <input type="file" name="gambar" accept="image/*">
                <input type="submit" value="Tambahkan Komentar">
            </form>
        </div>
    </div>
</body>
</html>
