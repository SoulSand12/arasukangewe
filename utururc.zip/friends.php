<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

$userId = $_SESSION['user_id'];

$usersJson = file_get_contents('users.json');
$users = json_decode($usersJson, true);

$friendRequests = isset($users[$userId]['friend_requests']) ? $users[$userId]['friend_requests'] : [];
$friends = isset($users[$userId]['friends']) ? $users[$userId]['friends'] : [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['add_friend'])) {
        $friendId = $_POST['friend_id'];
        sendFriendRequest($friendId, $userId);
    } elseif (isset($_POST['remove_friend'])) {
        $friendId = $_POST['friend_id'];
        removeFriend($friendId, $userId);
    } elseif (isset($_POST['confirm_request'])) {
        $requestId = $_POST['request_id'];
        confirmRequest($requestId, $userId);
    } elseif (isset($_POST['cancel_request'])) {
        $requestId = $_POST['request_id'];
        cancelRequest($requestId, $userId);
    }
}

function sendFriendRequest($friendId, $userId) {
    global $users;
    if (!in_array($friendId, $users[$userId]['friend_requests']) && !in_array($friendId, $users[$userId]['friends'])) {
        $users[$friendId]['friend_requests'][] = $userId;
        saveUsers($users);
    }
}

function removeFriend($friendId, $userId) {
    global $users;
    if (isset($users[$userId]['friends'][$friendId])) {
        unset($users[$userId]['friends'][$friendId]);
        unset($users[$friendId]['friends'][$userId]);
        saveUsers($users);
    }
}

function confirmRequest($requestId, $userId) {
    global $users;
    if (isset($users[$userId]['friend_requests'][$requestId])) {
        $friendId = $users[$userId]['friend_requests'][$requestId];
        // Add each user to the other's friend list
        $users[$userId]['friends'][$friendId] = $users[$friendId];
        $users[$friendId]['friends'][$userId] = $users[$userId];
        // Remove friend request
        unset($users[$userId]['friend_requests'][$requestId]);
        saveUsers($users);
    }
}

function cancelRequest($requestId, $userId) {
    global $users;
    if (isset($users[$userId]['friend_requests'][$requestId])) {
        $friendId = $users[$userId]['friend_requests'][$requestId];
        unset($users[$userId]['friend_requests'][$requestId]);
        saveUsers($users);
    }
}

function saveUsers($users) {
    $usersJson = json_encode($users, JSON_PRETTY_PRINT);
    file_put_contents('users.json', $usersJson);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Friends</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
        }
        .container {
            max-width: 800px;
            margin: 20px auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        .friend {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 10px;
            border-bottom: 1px solid #ccc;
        }
        .friend img {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            margin-right: 10px;
        }
        .friend .username {
            font-weight: bold;
        }
        .friend .actions {
            display: flex;
        }
        .friend .actions button {
            margin-left: 10px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Friends</h2>
        <?php foreach ($friends as $friendId => $friend): ?>
            <div class="friend">
                <img src="<?php echo $friend['profile_picture']; ?>" alt="<?php echo $friend['username']; ?>">
                <div class="username"><?php echo $friend['username']; ?></div>
                <div class="actions">
                    <form action="friend.php" method="post">
                        <input type="hidden" name="friend_id" value="<?php echo $friendId; ?>">
                        <button type="submit" name="remove_friend">Remove</button>
                    </form>
                </div>
            </div>
        <?php endforeach; ?>
        <h2>Friend Requests</h2>
        <?php foreach ($friendRequests as $requestId => $request): ?>
            <div class="friend">
                <img src="<?php echo $request['profile_picture']; ?>" alt="<?php echo $request['username']; ?>">
                <div class="username"><?php echo $request['username']; ?></div>
                <div class="actions">
                    <form action="friend.php" method="post">
                        <input type="hidden" name="request_id" value="<?php echo $requestId; ?>">
                        <button type="submit" name="confirm_request">Confirm</button>
                        <button type="submit" name="cancel_request">Cancel</button>
                    </form>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
</body>
</html>