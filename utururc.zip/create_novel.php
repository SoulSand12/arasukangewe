<?php
session_start();

// Redirect user to login page if not logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

// Check if form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Validate form data
    if (isset($_POST['judul']) && isset($_FILES['gambar']) && $_FILES['gambar']['error'] === UPLOAD_ERR_OK) {
        // Get user ID and form data
        $userId = $_SESSION['user_id'];
        $judul = $_POST['judul'];
        $gambarName = $_FILES['gambar']['name'];
        $gambarTmpName = $_FILES['gambar']['tmp_name'];

        // Directory to store novel images
        $uploadDir = 'novel_images/';
        // Path to upload the image
        $uploadPath = $uploadDir . $gambarName;

        // Move the uploaded image to the novel images directory
        if (move_uploaded_file($gambarTmpName, $uploadPath)) {
            // Load existing novel data or initialize if not exists
            $novelData = [];
            if (file_exists('novel_data.json')) {
                $novelData = json_decode(file_get_contents('novel_data.json'), true);
            }

            // Generate unique ID for the novel
            $novelId = uniqid('novel_');

            // Add novel data to the array
            $novelData[$novelId] = [
                'author' => $userId,
                'icon' => $uploadPath,
                'judul' => $judul,
                'chapters' => []
            ];

            // Save novel data back to the JSON file
            file_put_contents('novel_data.json', json_encode($novelData, JSON_PRETTY_PRINT));

            // Redirect to write_novel.php with novel ID
            header("Location: write_novel.php?id=$novelId");
            exit();
        } else {
            echo "Failed to upload the image.";
        }
    } else {
        echo "Invalid form data.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Novel</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }
        .container {
            max-width: 600px;
            margin: 20px auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        h2 {
            text-align: center;
            margin-bottom: 20px;
        }
        form {
            text-align: center;
        }
        label {
            display: block;
            margin-bottom: 10px;
            font-weight: bold;
        }
        input[type="text"],
        input[type="file"] {
            width: 100%;
            padding: 10px;
            margin-bottom: 20px;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-sizing: border-box;
        }
        button[type="submit"] {
            padding: 10px 20px;
            background-color: #007bff;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }
        button[type="submit"]:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Create Novel</h2>
        <form method="post" enctype="multipart/form-data">
            <label for="judul">Judul Novel:</label>
            <input type="text" id="judul" name="judul" required>
            <label for="gambar">Gambar Novel:</label>
            <input type="file" id="gambar" name="gambar" accept="image/*" required>
            <button type="submit">Create Novel</button>
        </form>
    </div>
</body>
</html>