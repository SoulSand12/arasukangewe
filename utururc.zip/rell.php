<?php  

$ea = readdir('./plugin/');
echo $ea;
?>