<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

$userId = $_SESSION['user_id'];
$otherUserId = $_GET['user_id'] ?? null;
$roomId = $_GET['room_id'] ?? null;

if (!$otherUserId || !$roomId) {
    header('Location: index.php');
    exit();
}

$users = json_decode(file_get_contents('users.json'), true);

$privateChats = json_decode(file_get_contents('private_chat_db/chat_private_data.json'), true);
$chatData = $privateChats[$roomId] ?? null;

if (!$chatData || !in_array($userId, $chatData['members'])) {
    header('Location: index.php');
    exit();
}

$messages = $chatData['chat'] ?? [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $message = htmlspecialchars($_POST['message']);
    $timestamp = time();
    $messageData = [
        'sender_id' => $userId,
        'message' => $message,
        'timestamp' => $timestamp,
    ];

    $messages[] = $messageData;
    $privateChats[$roomId]['chat'] = $messages;

    file_put_contents('private_chat_db/chat_private_data.json', json_encode($privateChats, JSON_PRETTY_PRINT));
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Private Chat</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }

        .chat-container {
            max-width: 800px;
            margin: auto;
            padding: 20px;
            background-color: #fff;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
            margin-top: 50px;
        }

        .chat-header {
            background-color: #3498db;
            color: #fff;
            padding: 10px;
            text-align: center;
            font-size: 20px;
            border-radius: 8px 8px 0 0;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .chat-header a {
            color: #fff;
            text-decoration: none;
        }

        .chat-box {
            background-color: #fff;
            border: 1px solid #ddd;
            padding: 15px;
            border-radius: 0 0 8px 8px;
            margin-top: 15px;
            max-height: 400px;
            overflow-y: auto;
        }

        .input-container {
            display: flex;
            margin-top: 15px;
        }

        .message-input {
            flex: 1;
            padding: 10px;
            box-sizing: border-box;
            border: 1px solid #ddd;
            border-radius: 4px;
            margin-right: 10px;
        }

        .send-button {
            background-color: #3498db;
            color: #fff;
            padding: 10px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        .send-button:hover {
            background-color: #2980b9;
        }

        .message {
            display: flex;
            align-items: center;
            margin-bottom: 15px;
        }

        .message img {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            margin-right: 10px;
            border: 1px solid #ddd;
        }

        .message-content {
            flex: 1;
            background-color: #f1f1f1;
            padding: 10px;
            border-radius: 8px;
        }
.sent-message {
    justify-content: flex-end;
}

.sent-message .message-content {
    background-color: #3498db;
    color: #fff;
}

.received-message .message-content {
    background-color: #f1f1f1;
}

    </style>
</head>
<body>
    <div class="chat-container">
        <div class="chat-header">
            Private Chat with <?php echo $users[$otherUserId]['username']; ?>
            <a href="index.php">Back</a>
        </div>
        <div class="chat-box" id="chatBox">
<?php
foreach ($messages as $message) {
    $senderId = $message['sender_id'];
    $senderName = $users[$senderId]['username'];
    $senderProfilePicture = $users[$senderId]['profile_picture'];
    $messageContent = $message['message'];
    $timestamp = date("H:i:s", $message['timestamp']);

    // Tentukan class untuk menentukan apakah pesan dari pengirim atau penerima
    $messageClass = ($senderId == $userId) ? 'sent-message' : 'received-message';
?>
    <div class="message <?php echo $messageClass; ?>">
        <img src="<?= $senderProfilePicture ?>" alt="Profile Picture">
        <div class="message-content">
            <strong><?= $senderName ?></strong> <?= $timestamp ?><br>
            <?= $messageContent ?>
        </div>
    </div>
<?php } ?>

        </div>
        <form method="post" action="private_chat.php?room_id=<?php echo $roomId; ?>" class="input-container">
            <input type="text" name="message" class="message-input" placeholder="Type your message" required>
            <button type="submit" class="send-button">Send</button>
        </form>
    </div>
    <script>
        function fetchMessages() {
            const chatBox = document.getElementById('chatBox');
            const roomId = '<?php echo $roomId; ?>';
            const fetchUrl = `get_private_chat.php?room_id=${roomId}`;

            fetch(fetchUrl)
                .then(response => response.json())
                .then(messages => {
                    chatBox.innerHTML = '';
                    messages.forEach(message => {
                        const senderName = message.sender_name;
                        const senderProfilePicture = message.sender_profile_picture;
                        const messageContent = message.message_content;
                        const timestamp = message.timestamp;

                        const messageElement = document.createElement('div');
                        messageElement.className = 'message';

                        const profilePictureElement = document.createElement('img');
                        profilePictureElement.src = senderProfilePicture;
                        profilePictureElement.alt = 'Profile Picture';

                        const messageContentElement = document.createElement('div');
                        messageContentElement.className = 'message-content';
                        messageContentElement.innerHTML = `<strong>${senderName}</strong> ${timestamp}<br>${messageContent}`;

                        messageElement.appendChild(profilePictureElement);
                        messageElement.appendChild(messageContentElement);

                        chatBox.appendChild(messageElement);
                    });

                    chatBox.scrollTop = chatBox.scrollHeight;
                })
                .catch(error => console.error('Error fetching messages:', error));
        }

        fetchMessages();
        setInterval(fetchMessages, 5000);
    </script>
</body>
</html>
